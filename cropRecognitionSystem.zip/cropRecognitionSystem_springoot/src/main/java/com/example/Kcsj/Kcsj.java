package com.example.Kcsj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kcsj {

    public static void main(String[] args) {
        SpringApplication.run(Kcsj.class, args);
    }

}
