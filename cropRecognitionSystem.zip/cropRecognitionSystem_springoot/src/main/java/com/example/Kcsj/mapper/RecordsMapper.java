package com.example.Kcsj.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.Kcsj.entity.Records;

public interface RecordsMapper extends BaseMapper<Records> {
}
